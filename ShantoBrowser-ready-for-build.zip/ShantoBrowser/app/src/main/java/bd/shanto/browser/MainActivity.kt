package bd.shanto.browser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.net.http.SslError
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("local", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var bar: EditText
    private lateinit var status: TextView
    private lateinit var web: WebView
    // Interception can run off the UI thread. Publish a fresh, immutable snapshot.
    @Volatile private var active: Set<String> = emptySet()
    private fun saved(key: String) = prefs.getStringSet(key, emptySet()).orEmpty().toSet()
    private fun save(key: String, values: Set<String>) {
        prefs.edit().putStringSet(key, values.toSet()).apply()
    }
    private fun filterOn() = prefs.getBoolean("filter", true)
    private fun policy(url: String): String? {
        val h = Rules.host(url) ?: return "ঠিকানাটি গ্রহণযোগ্য নয়। সাধারণ HTTPS ডোমেইন ব্যবহার করুন।"
        return if (Rules.blocked(h, active)) "ব্লক করা হয়েছে: $h — আপনার ডোমেইন তালিকার নিয়ম।" else null
    }
    private fun note(s: String) {
        status.text = s
        status.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
    }
    private fun button(row: LinearLayout, text: String, action: () -> Unit) {
        row.addView(Button(this).apply { this.text = text; setOnClickListener { action() } })
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        active = if (filterOn()) saved("blocks") else emptySet()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isFocusableInTouchMode = true }
        setContentView(root)
        val first = LinearLayout(this); root.addView(first)
        bar = EditText(this).apply {
            hint = "ওয়েব ঠিকানা বা সার্চ"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) { submit(); true } else false
            }
        }
        first.addView(bar, LinearLayout.LayoutParams(0, -2, 1f)); button(first, "Go", ::submit)
        val scroll = HorizontalScrollView(this); root.addView(scroll)
        val row = LinearLayout(this); scroll.addView(row)
        button(row, "Back") { move(-1) }; button(row, "Forward") { move(1) }
        button(row, "Reload") {
            web.url?.let { url -> policy(url)?.let(::note) ?: run { note(""); web.reload() } }
        }
        button(row, "Home", ::home); button(row, "বুকমার্ক", ::bookmarks); button(row, "সেটিংস", ::settings)
        status = TextView(this).apply { setPadding(16, 12, 16, 12); accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        root.addView(status); home()
    }
    private fun home() {
        if (::web.isInitialized) { root.removeView(web); web.stopLoading(); web.destroy() }
        web = WebView(this).apply { importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS }
        with(web.settings) {
            javaScriptEnabled = false; domStorageEnabled = false
            allowFileAccess = false; allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true; setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        CookieManager.getInstance().apply { setAcceptCookie(false); setAcceptThirdPartyCookies(web, false) }
        web.setDownloadListener { _, _, _, _, _ -> note("এই সংস্করণে ডাউনলোড বন্ধ।") }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val why = policy(r.url.toString()) ?: return false
                if (r.isForMainFrame && v === web) note(why)
                return true
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val why = policy(r.url.toString()) ?: return null
                return WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", emptyMap(), why.byteInputStream())
            }
            override fun onPageStarted(v: WebView, url: String, icon: android.graphics.Bitmap?) {
                if (v !== web) return
                val why = policy(url)
                if (why != null) { home(); note(why); return }
                bar.setText(url); note("")
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (v === web && r.isForMainFrame) note("পেজ খোলা যায়নি। ইন্টারনেট ও ঠিকানা পরীক্ষা করে Reload চাপুন।")
            }
            override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, response: WebResourceResponse) {
                if (v === web && r.isForMainFrame) note(policy(r.url.toString()) ?: "সাইট পেজটি দিতে পারেনি (HTTP ${response.statusCode})।")
            }
            override fun onReceivedSslError(v: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel(); if (v === web) note("নিরাপদ সংযোগ যাচাই হয়নি। অনুরোধটি বাতিল করা হয়েছে।")
            }
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f)); bar.setText("")
        note("হোম • উপরে সার্চ বা HTTPS ঠিকানা লিখুন। আরও বোতাম দেখতে বোতামের সারি বাঁয়ে টানুন।")
    }
    private fun submit() {
        val url = Rules.address(bar.text.toString(), prefs.getBoolean("google", false))
        if (url == null) { note("ভুল বা অসমর্থিত ঠিকানা। যেমন: https://example.org"); return }
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(bar.windowToken, 0)
        open(url)
    }
    private fun open(url: String) {
        val why = policy(url); if (why != null) { note(why); return }
        bar.clearFocus(); note(""); web.loadUrl(url)
    }
    private fun move(step: Int) {
        val history = web.copyBackForwardList(); val i = history.currentIndex + step
        if (i !in 0 until history.size) { note("এদিকে আর কোনো পেজ নেই।"); return }
        val why = policy(history.getItemAtIndex(i).url)
        if (why == null) web.goBackOrForward(step) else note(why)
    }
    @Deprecated("Platform back callback")
    override fun onBackPressed() { if (web.canGoBack()) move(-1) else super.onBackPressed() }
    private fun menu(title: String, items: List<String>, pick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, i -> pick(i) }
            .setNegativeButton("বন্ধ", null).show()
    }
    private fun resetPolicy() {
        active = if (filterOn()) saved("blocks") else emptySet()
        home(); note("নিয়ম সংরক্ষিত। আগের পেজ ও Back/Forward তালিকা বন্ধ করা হয়েছে।")
    }
    private fun settings() {
        val google = prefs.getBoolean("google", false)
        menu("সেটিংস", listOf("ডোমেইন ফিল্টার: " + (if (filterOn()) "চালু (বন্ধ করুন)" else "বন্ধ (চালু করুন)"),
            "সার্চ ইঞ্জিন: " + (if (google) "Google" else "DuckDuckGo"), "ব্লক-লিস্টে যোগ", "ব্লক-লিস্ট থেকে বাদ", "ফিল্টারের সীমা")) { i ->
            when (i) {
                0 -> { prefs.edit().putBoolean("filter", !filterOn()).apply(); resetPolicy() }
                1 -> menu("বার থেকে সার্চ হবে", listOf("DuckDuckGo", "Google")) { n ->
                    prefs.edit().putBoolean("google", n == 1).apply(); note("পরের সার্চে নতুন পছন্দ ব্যবহার হবে।") }
                2 -> {
                    val field = EditText(this).apply { hint = "example.org"; setSingleLine() }
                    AlertDialog.Builder(this).setTitle("শুধু ডোমেইন লিখুন").setView(field)
                        .setPositiveButton("যোগ") { _, _ ->
                            val h = Rules.domain(field.text.toString())
                            if (h == null) note("ঠিক ডোমেইন লিখুন; https:// বা পথ দেবেন না।")
                            else { save("blocks", saved("blocks") + h); resetPolicy() }
                        }.setNegativeButton("বাতিল", null).show()
                }
                4 -> AlertDialog.Builder(this).setTitle("ফিল্টারের সীমা")
                    .setMessage("তালিকার বাইরে থাকা সাইট বা একই সাইটের আলাদা ছবি ও লেখা শনাক্ত করা হয় না। SafeSearch শুধু বার থেকে সার্চ করার সময় অনুরোধ করা হয়। এটি সম্পূর্ণ সুরক্ষা বা ধর্মীয় সনদ নয়।")
                    .setPositiveButton("বুঝেছি", null).show()
                3 -> chooseSaved("blocks", "বাদ দিতে ডোমেইন চাপুন") { h -> save("blocks", saved("blocks") - h); resetPolicy() }
            }
        }
    }
    private fun chooseSaved(key: String, title: String, choose: (String) -> Unit) {
        val entries = saved(key).sorted()
        if (entries.isEmpty()) note("তালিকা খালি।") else menu(title, entries) { choose(entries[it]) }
    }
    private fun bookmarks() {
        menu("বুকমার্ক", listOf("বর্তমান পেজ রাখুন", "খুলুন", "মুছুন")) { i ->
            when (i) {
                0 -> {
                    val url = web.url
                    if (url == null || policy(url) != null) note("আগে একটি অনুমোদিত পেজ খুলুন।")
                    else { save("marks", saved("marks") + url); note("বুকমার্ক ফোনে রাখা হয়েছে।") }
                }
                1 -> chooseSaved("marks", "বুকমার্ক খুলুন", ::open)
                2 -> chooseSaved("marks", "মুছতে ঠিকানা চাপুন") { save("marks", saved("marks") - it); note("বুকমার্ক মোছা হয়েছে।") }
            }
        }
    }
    override fun onDestroy() { root.removeView(web); web.destroy(); super.onDestroy() }
}
